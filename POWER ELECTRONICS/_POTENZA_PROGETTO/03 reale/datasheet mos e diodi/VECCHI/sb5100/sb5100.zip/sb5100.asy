Version 4
SymbolType BLOCK
LINE Normal 16 -16 -16 -16
LINE Normal 0 -16 -16 7
LINE Normal 16 7 0 -16
LINE Normal -16 7 16 7
LINE Normal 0 -48 0 -16
LINE Normal 0 7 0 32
WINDOW 0 48 -32 Left 2
WINDOW 3 48 0 Left 2
WINDOW 39 48 32 Left 2
SYMATTR Value SB5100
SYMATTR SpiceLine Vrrm=100 Vrsm=100 Ir=500u Irsm=500u Vf=0.79 Ifav=5 Rs=.01 trr=5n Cj=200p Eg=0.69 Xti=2
SYMATTR Prefix X
SYMATTR ModelFile .\sb5100_spice.lib
PIN 0 32 RIGHT 8
PINATTR PinName A
PINATTR SpiceOrder 1
PIN 0 -48 RIGHT 8
PINATTR PinName K
PINATTR SpiceOrder 2
